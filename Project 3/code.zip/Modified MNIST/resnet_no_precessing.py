# -*- coding: utf-8 -*-


#import needed classes
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2 as cv
import matplotlib.pyplot as plt
import keras

from keras.datasets import cifar10
from keras.layers import Dense,Conv2D,MaxPooling2D,Flatten,AveragePooling2D,Dropout,BatchNormalization,Activation,GlobalMaxPooling2D
from keras.models import Model,Input
from keras.optimizers import Adam, SGD
from keras.callbacks import LearningRateScheduler
from keras.callbacks import ModelCheckpoint
from math import ceil
import os
from keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split

#Files are stored in pickle format.
#Load them like how you load any pickle. The data is a numpy array
train_images = pd.read_pickle('train_images.pkl')
train_labels = pd.read_csv('train_labels.csv')
test_images = pd.read_pickle('test_images.pkl')

train_set = train_images.copy()
train_set /= 255.
train_set -= np.mean(train_set)
train_set /= np.std(train_set)
train_set[train_set<0] = 0 

X_train = np.expand_dims(train_set,axis=-1)        
print (X_train.shape,'train samples shape')

y_train = keras.utils.to_categorical(np.array(train_labels)[:,1], 10)


X_train1, X_val, Y_train, Y_val = train_test_split(X_train, y_train, test_size = 0.33, random_state=42)



def Unit(x,filters,pool=False):
    res = x
    if pool:
        x = MaxPooling2D(pool_size=(2, 2))(x)
        res = Conv2D(filters=filters,kernel_size=[1,1],strides=(2,2),padding="same")(res)
    out = BatchNormalization()(x)
    out = Activation("relu")(out)
    out = Conv2D(filters=filters, kernel_size=[3, 3], strides=[1, 1], padding="same")(out)

    out = BatchNormalization()(out)
    out = Activation("relu")(out)
    out = Conv2D(filters=filters, kernel_size=[3, 3], strides=[1, 1], padding="same")(out)

    out = keras.layers.add([res,out])

    return out


def MiniModel(input_shape):
    images = Input(input_shape)
    net = Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding="same")(images)
    net = Unit(net, 64)
    net = Unit(net, 64)
    net = Unit(net, 64)
 
    net = Unit(net, 128, pool=True)
    net = Unit(net, 128)
    net = Unit(net, 128)
 
    net = Unit(net, 256, pool=True)
    net = Unit(net, 256)
    net = Unit(net, 256)
 
    net = Unit(net, 512, pool=True)
    net = Unit(net, 512)
    net = Unit(net, 512)
 
    net = BatchNormalization()(net)
    net = Activation("relu")(net)
    #net = Dropout(0.25)(net)
 
    net = AveragePooling2D(pool_size=(4, 4))(net)
    net = GlobalMaxPooling2D()(net)
    net = Dense(2048)(net)
    net = BatchNormalization()(net)
    #net = Dropout(0.4)(net)
    net = Dense(1024)(net)
    net = BatchNormalization()(net)
    #net = Dropout(0.2)(net)
    net = Dense(units=10, activation="softmax")(net)
 
    model = Model(inputs=images, outputs=net)
 
    return model


input_shape = (64,64,1)
model = MiniModel(input_shape)

model.compile(optimizer='sgd',loss='categorical_crossentropy',metrics=['accuracy'])

# Set a learning rate annealer
learning_rate_reduction = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=0.000001)

datagen = ImageDataGenerator(
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=False,
        vertical_flip=False,
        shear_range=0.5,
        zoom_range=(0.9, 1.1),
        fill_mode='constant',
        cval=0)

datagen.fit(X_train1)

hist = model.fit_generator(datagen.flow(X_train1,Y_train, batch_size=128),
                              epochs = 50, validation_data = (X_val,Y_val),
                              verbose = 1, steps_per_epoch=X_train.shape[0]/ 128
                              , callbacks=[learning_rate_reduction])




#prediction
test_set = test_images.copy()
test_set /= 255.
test_set -= np.mean(test_set)
test_set /= np.std(test_set)
test_set[test_set<0] = 0 

X_test = np.expand_dims(test_set,axis=-1)        
print (X_train.shape,'test samples shape')

y_prob = model.predict(X_test)
y_pred =  np.argmax(y_prob,axis=1)

#write to csv file

ids = np.zeros(len(y_pred)).astype('int32')

for i in range(len(y_pred)):
    ids[i] = i

submission = pd.DataFrame({'Category': y_pred, 
                           'Id': ids})
cols = submission.columns.tolist()
cols = cols[-1:] + cols[:-1]
submission = submission[cols]
submission = submission.sort_values(by=['Id'])
submission.to_csv('submission.csv', index=False)

submission.head(100)


