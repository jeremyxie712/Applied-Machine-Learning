



import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2 as cv
import matplotlib.pyplot as plt
import keras

from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten, Activation
from keras.layers import Conv2D, MaxPooling2D,BatchNormalization,GlobalMaxPooling2D
from keras.callbacks import ModelCheckpoint
from keras.utils.vis_utils import plot_model
from keras.optimizers import SGD, Adam, RMSprop
from keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split


#Files are stored in pickle format.
#Load them like how you load any pickle. The data is a numpy array
train_images = pd.read_pickle('train_images.pkl')
train_labels = pd.read_csv('train_labels.csv')
test_images = pd.read_pickle('test_images.pkl')

train_set = train_images.copy()
train_set -= np.mean(train_set)
train_set /= np.std(train_set)
train_set[train_set<0] = 0 

X_train = np.expand_dims(train_set,axis=-1)        
print (X_train.shape,'train samples shape')

y_train = keras.utils.to_categorical(np.array(train_labels)[:,1], 10)


X_train1, X_val, Y_train, Y_val = train_test_split(X_train, y_train, test_size = 0.33, random_state=42)

input_shape = (64,64,1)

model = Sequential()
model.add(Conv2D(filters=128, input_shape=input_shape,padding='same',kernel_size=(3,3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Conv2D(filters=128, padding='same',kernel_size=(3,3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Conv2D(filters=128, padding='same',kernel_size=(5,5)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))


model.add(Conv2D(filters=256, input_shape=input_shape,padding='same',kernel_size=(3,3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Conv2D(filters=256, padding='same',kernel_size=(3,3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Conv2D(filters=256, padding='same',kernel_size=(5,5)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(filters=512, input_shape=input_shape,padding='same',kernel_size=(3,3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Conv2D(filters=512, padding='same',kernel_size=(3,3)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(Conv2D(filters=512, padding='same',kernel_size=(5,5)))
model.add(Activation('relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))


model.add(GlobalMaxPooling2D())
model.add(Dense(1024, activation='relu'))
model.add(BatchNormalization())
model.add(Dense(512, activation='relu'))
model.add(BatchNormalization())
model.add(Dense(10, activation='softmax'))

model.compile(optimizer='sgd',loss='categorical_crossentropy',metrics=['accuracy'])






learning_rate_reduction = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=0.000001)

datagen = ImageDataGenerator(
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=False,
        vertical_flip=False,
        shear_range=0.5,
        zoom_range=(0.9, 1.1),
        fill_mode='constant',
        cval=0)



datagen.fit(X_train1)

h = model.fit_generator(datagen.flow(X_train1,Y_train, batch_size=128),
                              epochs = 50, validation_data = (X_val,Y_val),
                              verbose = 1, steps_per_epoch=X_train.shape[0]/ 128
                              , callbacks=[learning_rate_reduction])



hist = model.fit(X_train, y_train,
          batch_size=128,
          epochs=50,
          verbose=1,
          validation_split=0.33,
          callbacks=[learning_rate_reduction])







print ('History', hist.history)

print(hist.history.keys())
# summarize history for accuracy
plt.plot(hist.history['acc'])
plt.plot(hist.history['val_acc'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
#plt.savefig('acc')
plt.show()
# summarize history for loss
plt.plot(hist.history['loss'])
plt.plot(hist.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
#plt.savefig('loss')
plt.show()






#prediction
test_set = test_images.copy()
test_set -= np.mean(test_set)
test_set /= np.std(test_set)
test_set[test_set<0] = 0 

X_test = np.expand_dims(test_set,axis=-1)        
print (X_train.shape,'test samples shape')

y_pred = model.predict_classes(X_test)



ids = np.zeros(len(y_pred)).astype('int32')

for i in range(len(y_pred)):
    ids[i] = i

submission = pd.DataFrame({'Category': y_pred, 
                           'Id': ids})
cols = submission.columns.tolist()
cols = cols[-1:] + cols[:-1]
submission = submission[cols]
submission = submission.sort_values(by=['Id'])
submission.to_csv('submission.csv', index=False)

submission.head(100)



