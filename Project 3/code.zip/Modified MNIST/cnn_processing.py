

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2 as cv

# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory


def image_processing(input_im_array):
    output_im_array = np.zeros(input_im_array.shape, dtype = 'float32')
    for i in range(input_im_array.shape[0]):
        current_im = input_im_array[i]
        
        #normalization
        current_im -= np.mean(current_im)
        current_im /= np.max(current_im)
        current_im[current_im<0] = 0
    
        #binarize
        ret,current_im = cv.threshold(current_im,0.5,1,cv.THRESH_BINARY)
        
    
        #remove background with morph opening
        kernel = np.ones((3,3),np.uint8)
        current_im = cv.morphologyEx(current_im, cv.MORPH_OPEN, kernel)
        
        output_im_array[i,:,:] = current_im

    return output_im_array


def extract_largest_num(input_im_array):
    output_im_array = np.zeros((input_im_array.shape[0],28,28), dtype = 'float32')
    for i in range(input_im_array.shape[0]):
        current_im = input_im_array[i]
        
        #set to uint8
        current_im = current_im.astype(np.uint8)
        
        #find contur
        _, contours, _ = cv.findContours(current_im, cv.RETR_EXTERNAL,cv.CHAIN_APPROX_SIMPLE)
        
        tmp_size = 0
        for contour in contours:
            x,y,w,h = cv.boundingRect(contour)
            if w*h > tmp_size:
                tmp_size = w*h
                tmp_roi = current_im[y:y+h, x:x+w]
        
        roi = np.pad(tmp_roi, ((3,3),(3,3)), 'constant')
        roi = cv.resize(roi,(28,28), 0, 0, interpolation = cv.INTER_AREA) 
        output_im_array[i,:,:] = roi
        
    return output_im_array.astype('float32')

#Files are stored in pickle format.
#Load them like how you load any pickle. The data is a numpy array
train_images = pd.read_pickle('train_images.pkl')
train_labels = pd.read_csv('train_labels.csv')
test_images = pd.read_pickle('test_images.pkl')


import matplotlib.pyplot as plt


train_set = image_processing(train_images)
train_set_selected = extract_largest_num(train_set)


X_train = np.expand_dims(train_set_selected,axis=-1)        
print (X_train.shape,'train samples shape')

import keras
y_train = keras.utils.to_categorical(np.array(train_labels)[:,1], 10)



from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D,BatchNormalization
from keras.callbacks import ModelCheckpoint
from keras.utils.vis_utils import plot_model
from keras.optimizers import SGD, Adam, RMSprop
from keras.preprocessing.image import ImageDataGenerator


















from sklearn.model_selection import train_test_split
X_train, X_val, Y_train, Y_val = train_test_split(X_train, y_train, test_size = 0.33, random_state=42)

input_shape = (28,28,1)

model = Sequential()


model.add(Conv2D(filters=64,activation='relu', input_shape=input_shape,padding='valid',kernel_size=(5,5)))
model.add(BatchNormalization())
model.add(Conv2D(filters=64,activation='relu', padding='valid',kernel_size=(5,5)))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Conv2D(filters=128, activation='relu',padding='valid',kernel_size=(5,5)))
model.add(BatchNormalization())
model.add(Conv2D(filters=128, activation='relu',padding='valid',kernel_size=(5,5)))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))


model.add(Flatten())  
model.add(Dense(1024, activation='relu'))
model.add(Dense(512, activation='relu'))
model.add(Dense(10, activation='softmax'))


model.compile(optimizer='sgd',loss='categorical_crossentropy',metrics=['accuracy'])

datagen = ImageDataGenerator(horizontal_flip = True,
                         vertical_flip = True,
                         width_shift_range = 0.1,
                         height_shift_range = 0.1,
                         zoom_range = 0.1,
                         rotation_range = 10
                        )

batch_size=128
learning_rate_reduction = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=1e-6)
datagen.fit(X_train)
hist = model.fit_generator(datagen.flow(X_train,Y_train, batch_size=batch_size),
                              epochs = 200, validation_data =(X_val,Y_val),
                              verbose = 1, steps_per_epoch=X_train.shape[0]/ batch_size
                              , callbacks=[learning_rate_reduction])

#model.fit(X_train, y_train, batch_size=128, epochs=50, verbose=1, shuffle=True,validation_split=0.33)  
#score = model.evaluate(x_test, y_test, verbose=1)























# Set the CNN model 
# my CNN architechture is In -> [[Conv2D->relu]*2 -> MaxPool2D -> Dropout]*2 -> Flatten -> Dense -> Dropout -> Out


model = Sequential()

model.add(Conv2D(filters = 6, kernel_size = (5,5),padding = 'Same', 
                 activation ='relu', input_shape = (28,28,1)))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2,2)))


model.add(Conv2D(filters = 16, kernel_size = (3,3),padding = 'Same', 
                 activation ='relu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2,2), strides=(2,2)))


model.add(Flatten())
model.add(Dense(120, activation = "relu"))
model.add(BatchNormalization())
model.add(Dense(84, activation = "relu"))
model.add(BatchNormalization())
model.add(Dense(10, activation = "softmax"))

optimizer = RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)
model.compile(optimizer = optimizer , loss = "categorical_crossentropy", metrics=["accuracy"])

# Set a learning rate annealer
learning_rate_reduction = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=0.00001)

epochs = 30 # Turn epochs to 30 to get 0.9967 accuracy
batch_size = 86


model.fit(X_train, y_train,
          batch_size=batch_size,
          epochs=epochs,
          verbose=1,
          validation_split=0.33,
          callbacks=[learning_rate_reduction])


#########################################

from sklearn.model_selection import train_test_split


X_train, X_val, Y_train, Y_val = train_test_split(X_train, y_train, test_size = 0.33, random_state=42)

batch_size = 64
num_classes = 10
epochs = 50
input_shape = (28, 28, 1)

model = Sequential()
model.add(Conv2D(64, kernel_size=(3, 3),activation='relu',kernel_initializer='he_normal',input_shape=input_shape))
model.add(BatchNormalization())
model.add(Conv2D(64, kernel_size=(3, 3),activation='relu',kernel_initializer='he_normal'))
model.add(BatchNormalization())
model.add(MaxPooling2D((2, 2)))
#model.add(Dropout(0.20))
model.add(Conv2D(64, (3, 3), activation='relu',padding='same',kernel_initializer='he_normal'))
model.add(BatchNormalization())
model.add(Conv2D(64, (3, 3), activation='relu',padding='same',kernel_initializer='he_normal'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
#model.add(Dropout(0.25))
#model.add(Conv2D(128, (3, 3), activation='relu',padding='same',kernel_initializer='he_normal'))
#model.add(Dropout(0.25))
model.add(Conv2D(128, (3, 3), activation='relu',padding='same',kernel_initializer='he_normal'))
model.add(BatchNormalization())
model.add(Conv2D(128, (3, 3), activation='relu',padding='same',kernel_initializer='he_normal'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))


model.add(Flatten())
model.add(Dense(256, activation='relu'))
model.add(BatchNormalization())
model.add(Dense(1024, activation='relu'))
model.add(BatchNormalization())
#model.add(Dropout(0.25))
model.add(Dense(num_classes, activation='softmax'))

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.RMSprop(),
              metrics=['accuracy'])

learning_rate_reduction = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=1e-6)

datagen = ImageDataGenerator(
        featurewise_center=False,  # set input mean to 0 over the dataset
        samplewise_center=False,  # set each sample mean to 0
        featurewise_std_normalization=False,  # divide inputs by std of the dataset
        samplewise_std_normalization=False,  # divide each input by its stdcyst1314
        
        zca_whitening=False,  # apply ZCA whitening
        rotation_range=15, # randomly rotate images in the range (degrees, 0 to 180)
        zoom_range = 0.1, # Randomly zoom image 
        width_shift_range=0.1,  # randomly shift images horizontally (fraction of total width)
        height_shift_range=0.1,  # randomly shift images vertically (fraction of total height)
        horizontal_flip=False,  # randomly flip images
        vertical_flip=False)  # randomly flip images

datagen.fit(X_train)
h = model.fit_generator(datagen.flow(X_train,Y_train, batch_size=batch_size),
                              epochs = epochs, validation_data = (X_val,Y_val),
                              verbose = 1, steps_per_epoch=X_train.shape[0]/ batch_size
                              , callbacks=[learning_rate_reduction])



###############################################################################################






model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3),activation='relu',padding='same',input_shape=(64,64,1)))
model.add(Conv2D(32, (3, 3), padding='same', activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Conv2D(64, (3, 3), padding='same', activation='relu'))
model.add(Conv2D(64, (3, 3), padding='same', activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

# =============================================================================
# model.add(Conv2D(128, (3, 3), padding='same', activation='relu'))
# model.add(Conv2D(128, (3, 3), padding='same', activation='relu'))
# model.add(MaxPooling2D(pool_size=(2, 2)))
# =============================================================================

model.add(Flatten())
model.add(Dense(128))
model.add(Dense(10, activation='softmax'))

num_epoch = 100
learning_rate = 0.05
decay_rate = 1e-6
opt = SGD(lr = learning_rate,decay=decay_rate)

model.compile(loss='categorical_crossentropy',
              optimizer=opt,
              metrics=['categorical_accuracy'])


model.fit(train_set, y_train,
          batch_size=64,
          epochs=num_epoch,
          verbose=1,
          validation_split=0.33)









