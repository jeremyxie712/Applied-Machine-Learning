# -*- coding: utf-8 -*-

#import needed classes
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import cv2 as cv
import matplotlib.pyplot as plt
import keras

from keras.datasets import cifar10
from keras.layers import GlobalAveragePooling2D,Dense,Conv2D,MaxPooling2D,Flatten,AveragePooling2D,Dropout,BatchNormalization,Activation,GlobalMaxPooling2D,concatenate
from keras.models import Model,Input
from keras.optimizers import Adam, SGD,RMSprop
from keras.callbacks import LearningRateScheduler
from keras.callbacks import ModelCheckpoint
from math import ceil
import os
from keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split

#Files are stored in pickle format.
#Load them like how you load any pickle. The data is a numpy array
train_images = pd.read_pickle('train_images.pkl')
train_labels = pd.read_csv('train_labels.csv')
test_images = pd.read_pickle('test_images.pkl')

train_set = train_images.copy()
train_set -= np.mean(train_set)
train_set /= np.std(train_set)
train_set[train_set<0] = 0 

X_train = np.expand_dims(train_set,axis=-1)        
print (X_train.shape,'train samples shape')

y_train = keras.utils.to_categorical(np.array(train_labels)[:,1], 10)


X_train1, X_val, Y_train, Y_val = train_test_split(X_train, y_train, test_size = 0.33, random_state=42)

def inception_module(x,filters):
    
    tower_1 = Conv2D(filters=filters,kernel_size=[1,1],strides=(1,1),padding="same")(x)
    tower_1 = Conv2D(filters=filters,kernel_size=[3,3],strides=(1,1),padding="same")(tower_1)
    tower_1 = Conv2D(filters=filters,kernel_size=[3,3],strides=(1,1),padding="same")(tower_1)
    
    tower_2 = Conv2D(filters=filters,kernel_size=[1,1],strides=(1,1),padding="same")(x)
    tower_2 = Conv2D(filters=filters,kernel_size=[3,3],strides=(1,1),padding="same")(tower_2)

    tower_3 = AveragePooling2D((3, 3), strides=(1, 1), padding='same')(x)
    tower_3 = Conv2D(filters=filters,kernel_size=[1,1],strides=(1,1),padding="same")(tower_3)
    
    tower_4 = Conv2D(filters=filters,kernel_size=[1,1],strides=(1,1),padding="same")(x)
    
    output = concatenate([tower_1,tower_2,tower_3,tower_4], axis=3)
    
    return output 


def MiniModel(input_shape):
    
    images = Input(input_shape)
    net = Conv2D(filters=32, kernel_size=[3, 3], strides=[1, 1], padding="same")(images)
    net = BatchNormalization()(net)
    net = Conv2D(filters=32, kernel_size=[3, 3], strides=[1, 1], padding="same")(net)
    net = BatchNormalization()(net)
    net = MaxPooling2D((3, 3), strides=(2, 2), padding='same')(net)
    
    net = Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding="same")(net)
    net = BatchNormalization()(net)
    net = Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding="same")(net)
    net = BatchNormalization()(net)
    net = MaxPooling2D((3, 3), strides=(2, 2), padding='same')(net)
    
    net = inception_module(net,64)
    net = inception_module(net,64)
    net = inception_module(net,64)
    
    aux = AveragePooling2D((5, 5), strides=3)(net)
    aux = Conv2D(128, (5, 5), padding='same', activation='relu')(aux)
    aux = Conv2D(128, (1, 1), padding='same', activation='relu')(aux)
    aux = GlobalAveragePooling2D()(aux)
    aux = Dense(1024)(aux)
    aux = Dense(10, activation='softmax')(aux)
    
    
    net = MaxPooling2D((3, 3), strides=(2, 2), padding='same')(net)
    
    net = inception_module(net,128)
    net = inception_module(net,128)
    net = inception_module(net,128)
    
    net = MaxPooling2D((3, 3), strides=(2, 2), padding='same')(net)
    
    net = GlobalAveragePooling2D()(net)
    net = Dense(1024)(net)
    #net = Dropout(0.2)(net)
    net = Dense(10, activation='softmax')(net)
    
    model = Model(inputs=images,outputs=[net, aux])
    
    return model
    
    
input_shape = (64,64,1)
model = MiniModel(input_shape)

model.compile(optimizer='sgd',loss=['categorical_crossentropy','categorical_crossentropy'],loss_weights=[1, 0.3],metrics=['accuracy'])

# Set a learning rate annealer
learning_rate_reduction = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', 
                                            patience=3, 
                                            verbose=1, 
                                            factor=0.5, 
                                            min_lr=0.000001)

datagen = ImageDataGenerator(
        rotation_range=20,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.5,
        zoom_range=(0.9, 1.1),
        horizontal_flip=False,
        vertical_flip=False,
        fill_mode='constant',
        cval=0)


datagen.fit(X_train1)
hist = model.fit_generator(datagen.flow(x = [X_train1,X_train1],y = [Y_train,Y_train], batch_size=128),
                              epochs = 60, validation_data =(X_val,[Y_val,Y_val]),
                              verbose = 1, steps_per_epoch=X_train.shape[0]/ 128
                              , callbacks=[learning_rate_reduction])


hist = model.fit(X_train1, [Y_train,Y_train],
          batch_size=128,
          epochs=50,
          verbose=1,
          validation_data =(X_val,[Y_val,Y_val]),
          callbacks=[learning_rate_reduction])
    
