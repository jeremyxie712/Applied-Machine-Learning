# -*- coding: utf-8 -*-

from keras.models import load_model
from sklearn.metrics import accuracy_score

inception_model = load_model('resNet.h5')
residual_model = load_model('resNet_doubleDense.h5')
vgg_model = load_model('3layerCNN_deep_wide_3conv.h5')


test_set = test_images.copy()
test_set /= 255.
test_set -= np.mean(test_set)
test_set /= np.std(test_set)
test_set[test_set<0] = 0 

X_test = np.expand_dims(test_set,axis=-1)        
print (test_set.shape,'test samples shape')

inception_prob = inception_model.predict(X_val)
residual_prob = residual_model.predict(X_val)
vgg_prob = vgg_model.predict(X_val)


test_true = np.argmax(Y_val,axis=1)

num_comb = [(0.3,0.4,0.3),(0.2,0.4,0.4),(0.4,0.4,0.2),(0.2,0.5,0.3),
            (0.3,0.5,0.2),(0.1,0.5,0.4),(0.4,0.5,0.1),(0.1,0.6,0.3),
            (0.3,0.6,0.1),(0.2,0.6,0.2),(0.1,0.7,0.2),(0.2,0.7,0.1),
            (0.1,0.8,0.1),(1/3,1/3,1/3),(0,0.5,0.5),(0,0.4,0.6),(0,0.6,0.4),
            (0,0.3,0.7,),(0,0.7,0.3)]


for comb in num_comb:
    prob = comb[0]*inception_prob + comb[1]*residual_prob + comb[2]*vgg_prob
    pred = np.argmax(prob,axis=1)
    score = accuracy_score(test_true,pred)
    print (comb,'weight',score,'acc')
    
    



#prediction
test_set = test_images.copy()
test_set /= 255.
test_set -= np.mean(test_set)
test_set /= np.std(test_set)
test_set[test_set<0] = 0 

X_test = np.expand_dims(test_set,axis=-1)        
print (X_train.shape,'test samples shape')

inception_prob = inception_model.predict(X_test)
residual_prob = residual_model.predict(X_test)
vgg_prob = vgg_model.predict(X_test)
y_prob = (0*inception_prob + 0.4*residual_prob + 0.6*vgg_prob)
y_pred =  np.argmax(y_prob,axis=1)

#write to csv file

ids = np.zeros(len(y_pred)).astype('int32')

for i in range(len(y_pred)):
    ids[i] = i

submission = pd.DataFrame({'Category': y_pred, 
                           'Id': ids})
cols = submission.columns.tolist()
cols = cols[-1:] + cols[:-1]
submission = submission[cols]
submission = submission.sort_values(by=['Id'])
submission.to_csv('submission.csv', index=False)

submission.head(100)

