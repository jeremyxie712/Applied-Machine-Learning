import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import cv2 as cv

import sklearn
from sklearn import svm, metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.neural_network import MLPClassifier


# import the data from files
train_images = pd.read_pickle('train_images.pkl')
train_labels = pd.read_csv('train_labels.csv')

# image processing: remove background    
processed_images = image_processing(train_images)

# get the number with the largest bounding box
largest_subimage = extract_largest_num(processed_images, train_images)

train_subimage = largest_subimage.copy()
train_subimage_flat = largest_subimage.reshape(40000, -1)
train_target = train_labels['Category']

X_train, X_test, y_train, y_test = train_test_split(train_subimage, train_target, test_size=0.33, random_state=42)
X_train_flat, X_test_flat, y_train_flat, y_test_flat = train_test_split(train_subimage_flat, train_target, test_size=0.33, random_state=42)

#SVM
params = {'C': [0.05, 0.5, 5, 50]}

clf = svm.SVC(max_iter = 1000)
svm_gscv = GridSearchCV(clf, params, cv=5, n_jobs=-1)
svm_gscv.fit(X_train_flat, y_train_flat)
svm_gscv.best_params_
svm_gscv.best_score_

#kNN
knn_param = {'n_neighbors': np.arange(3, 9)}

knn_clf = KNeighborsClassifier()
knn_gscv = GridSearchCV(knn_clf, knn_param, verbose=1, cv=5, n_jobs=-1)

knn_gscv.fit(X_train_flat, y_train_flat)
knn_gscv.best_params_
knn_gscv.best_score_

 

#mlp
parameter_space = {
    'hidden_layer_sizes': [(150,150,150), (150,200,150), (300,)],
}
mlp_clf = MLPClassifier(max_iter=200)
mlp_gscv = GridSearchCV(mlp_clf, parameter_space, n_jobs=-1, cv=5)
mlp_gscv.fit(X_train_flat, y_train_flat)
params=mlp_gscv.best_params_
mlp_gscv.best_score_



def image_processing(input_im_array):
    output_im_array = np.zeros(input_im_array.shape, dtype = 'float32')
    for i in range(input_im_array.shape[0]):
        current_im = input_im_array[i]
        
        #normalization
        current_im -= np.mean(current_im)
        current_im /= np.max(current_im)
        current_im[current_im<0] = 0
    
        #binarize
        ret,current_im = cv.threshold(current_im,0.5,1,cv.THRESH_BINARY)
        
    
        #remove background with morph opening
        kernel = np.ones((3,3),np.uint8)
        current_im = cv.morphologyEx(current_im, cv.MORPH_OPEN, kernel)
        
        output_im_array[i,:,:] = current_im

    return output_im_array


def extract_largest_num(input_im_array, original_im_array):
    output_im_array = np.zeros((input_im_array.shape[0],28,28), dtype = 'float32')
    for i in range(input_im_array.shape[0]):
        current_im = input_im_array[i]
        original_im = original_im_array[i]
        
        #set to uint8
        current_im = current_im.astype(np.uint8)
        
        #find contour
        _, contours, _ = cv.findContours(current_im, cv.RETR_EXTERNAL,cv.CHAIN_APPROX_SIMPLE)
        
        tmp_size = 0
        for contour in contours:
            x,y,w,h = cv.boundingRect(contour)
            offset = max(w,h)
            if offset*offset > tmp_size:
                tmp_size = offset*offset
                tmp_roi = original_im[y:y+h, x:x+w]
        
        roi = np.pad(tmp_roi, ((3,3),(3,3)), 'constant')
        roi = cv.resize(roi,(28,28), 0, 0, interpolation = cv.INTER_AREA) 
        output_im_array[i] = roi
        
    return output_im_array.astype('float32')